﻿namespace Azireno.Util
{
    public class Notification
    {

    }
}
