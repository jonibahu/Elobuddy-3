﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Azireno.Modes;
using Azireno.Plugin;
using EloBuddy;
using EloBuddy.SDK;
using EloBuddy.SDK.Enumerations;

namespace Azireno.Util
{
    static class SoldierController
    {
        public static void AutoPilot(List<Obj_AI_Minion> soldiers)
        {
            var target = TargetSelector.GetTarget(1100, DamageType.Magical);

            if (target == null || !target.IsValidTarget()) return;

            var predictedPositions = new Dictionary<int, Tuple<int, PredictionResult>>();
            var predictionQ = ModeModel.Q.GetPrediction(target);
            var predictionW = ModeModel.W.GetPrediction(target);
            var pos = target.Position;
            pos = ModeModel._Player.Distance(target) > ModeModel.W.Range ? ModeModel._Player.Position.Shorten(pos, -ModeModel.W.Range) : ModeModel._Player.Position.Extend(pos, ModeModel.W.Range).To3D();
            

            if (soldiers.Count == 0)
            {
                if (ModeModel.W.IsReady())
                {
                    ModeModel.W.Cast(pos);
                }
            }
            else if (soldiers.Count == 1)
            {
                if (soldiers.Count(validAzirSoldier => validAzirSoldier.Distance(target) < Orbwalker.AzirSoldierAutoAttackRange) > 0) return;

                if (ModeModel.W.IsReady())
                {
                    predictedPositions[target.NetworkId] = new Tuple<int, PredictionResult>(Environment.TickCount, predictionW);
                    ModeModel.W.Cast(pos);
                }

                if (ModeModel.Q.IsReady() && predictionQ.HitChance >= HitChance.Medium)
                {
                    predictedPositions[target.NetworkId] = new Tuple<int, PredictionResult>(Environment.TickCount, predictionW);
                    ModeModel.Q.Cast(predictionQ.CastPosition.Extend(predictionQ.UnitPosition, 50).To3D());
                }
            }
            else if (soldiers.Count == 2)
            {
                if (soldiers.Count(validAzirSoldier => validAzirSoldier.Distance(target) < Orbwalker.AzirSoldierAutoAttackRange) >= 1) return;

                if (ModeModel.Q.IsReady() && predictionQ.HitChance >= HitChance.Medium)
                {
                    predictedPositions[target.NetworkId] = new Tuple<int, PredictionResult>(Environment.TickCount,
                        predictionW);
                    ModeModel.Q.Cast(predictionQ.CastPosition.Extend(predictionQ.UnitPosition, 50).To3D());
                }
            }
            else
            {
                if (soldiers.Count(validAzirSoldier => validAzirSoldier.Distance(target) < Orbwalker.AzirSoldierAutoAttackRange) >= 2) return;

                if (ModeModel.Q.IsReady() && predictionQ.HitChance >= HitChance.Medium)
                {
                    predictedPositions[target.NetworkId] = new Tuple<int, PredictionResult>(Environment.TickCount,
                        predictionW);
                    ModeModel.Q.Cast(predictionQ.CastPosition);
                }
            }


        }


    }
}
