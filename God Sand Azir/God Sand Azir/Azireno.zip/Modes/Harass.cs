﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Azireno.Util;
using EloBuddy;
using EloBuddy.SDK;

namespace Azireno.Modes
{
    class Harass : ModeModel
    {
        public void Execute()
        {
            SoldierController.AutoPilot(Orbwalker.ValidAzirSoldiers);
        }

    }
}
