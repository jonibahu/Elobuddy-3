﻿using System;
using System.Collections.Generic;
using System.Linq;
using Azireno.Plugin;
using Azireno.Util;
using EloBuddy;
using EloBuddy.SDK;
using EloBuddy.SDK.Enumerations;
using SharpDX;

namespace Azireno.Modes
{
    class Combo : ModeModel
    {

        public void Execute()
        {
            SoldierController.AutoPilot(Orbwalker.ValidAzirSoldiers);
        }
    }
}
