﻿namespace Azireno.Plugin
{
    class Soldier
    {
    }
}
